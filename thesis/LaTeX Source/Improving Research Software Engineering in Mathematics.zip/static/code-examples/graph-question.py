# graph question in a standard format
def graph_question(
    questionID="Q0.1",
    title="Respondent type (Demographics: question 1)",
    IRSEMsubtitle="IRSEM: Mathematicians",
    URSSIsubtitle="URSSI: Research Software Engineers",
    statement="Respondent type",
    answersIRSEM=[],
    answersURSSI=[],
    percentage=True,
    stacked=False,
    labelrotation=46,
):

    # get question data for each survey
    QUESTION_DATA_IRSEM = [(statement, IRSEM[questionID][2:])]
    QUESTION_DATA_URSSI = [(statement, URSSI[questionID][2:])]

    # get lists of possible answers for each version of the question
    # the pandas conversion is necessary to remove the 'nan' values in the list
    if not answersIRSEM:
        ANSWER_DATA_IRSEM = (
            pd.Series(IRSEM[questionID][2:].sort_values().unique()).dropna().tolist()
        )
    else:
        ANSWER_DATA_IRSEM = answersIRSEM
    if not answersURSSI:
        ANSWER_DATA_URSSI = (
            pd.Series(URSSI[questionID][2:].sort_values().unique()).dropna().tolist()
        )
    else:
        ANSWER_DATA_URSSI = answersURSSI

    # create dataframes
    if percentage:
        df1 = pd.DataFrame(
            get_percentages(QUESTION_DATA_IRSEM, ANSWER_DATA_IRSEM), index=[statement]
        )
        df2 = pd.DataFrame(
            get_percentages(QUESTION_DATA_URSSI, ANSWER_DATA_URSSI), index=[statement]
        )
    else:
        df1 = pd.DataFrame(
            get_ans_counts(QUESTION_DATA_IRSEM, ANSWER_DATA_IRSEM), index=[statement]
        )
        df2 = pd.DataFrame(
            get_ans_counts(QUESTION_DATA_URSSI, ANSWER_DATA_URSSI), index=[statement]
        )

    # plot
    fig, (ax1, ax2) = plt.subplots(1, 2)
    fig.suptitle(title)

    ax1 = df1.plot.bar(rot=0, ax=ax1, stacked=stacked)
    ax1.set_title(IRSEMsubtitle)
    ax1.set_ylabel("Percentage %") if percentage else ax1.set_ylabel("Frequency")
    ax1.tick_params("x", labelrotation=labelrotation)
    if percentage:
        ax1.set_yticks(np.arange(0, 100.1, 5), minor=True)
    # ax1.get_legend().remove()

    ax2 = df2.plot.bar(rot=0, ax=ax2, stacked=stacked)
    ax2.set_title(URSSIsubtitle)
    ax2.set_ylabel("")
    ax2.tick_params("x", labelrotation=labelrotation)
    if percentage:
        ax2.set_yticks(np.arange(0, 100.1, 5), minor=True)

    # edit parameters
    plt.legend(bbox_to_anchor=(1.02, 1))
    plt.gcf().set_size_inches(12, 6)
    plt.show()