# function: find counts of each answer type on each question

def get_ans_counts(questions, answerTypes):
    ANSWERCOUNTS = {category: [] for category in answerTypes}
    for label, data in questions:
        for category in answerTypes:
            count = data.value_counts().get(category, 0)
            ANSWERCOUNTS[category].append(count)
    # print(ANSWERCOUNTS)
    return ANSWERCOUNTS


# function: get the percentages from the total counts of each category's responses
def get_percentages(questions, answerTypes):
    PERCENTAGES = {category: [] for category in answerTypes}
    for label, data in questions:
        for category in answerTypes:
            percent = data.value_counts(normalize=True).get(category, 0) * 100
            PERCENTAGES[category].append(percent)
    # print(totals)
    return PERCENTAGES


# functions to graph a likert matrix

def get_likert_data(
    survey=IRSEM,
    questionID="Q0.8",
    statements=["1 Person", "2 - 5 people", "6 - 20 people", "20+ people"],
):
    DATA = []
    for i, statement in enumerate(statements):
        DATA.append((statement, survey[questionID + "_" + str(i + 1)][2:]))
        # print(statement)

    return DATA

    # returns this data format:
    #   [('1 Person',             survey["Q0.8_1"][2:]),
    #    ('2 - 5 people',         survey["Q0.8_2"][2:]),
    #    ('6 - 20 people',        survey["Q0.8_3"][2:]),
    #    ('20+ people',           survey["Q0.8_4"][2:])]


def graph_likert_matrix(
    questionID="Q0.8",
    title="Team Size (Question 0.8)",
    IRSEMsubtitle="IRSEM: Mathematicians",
    URSSIsubtitle="URSSI: Research Software Engineers",
    statements=["1 Person", "2 - 5 people", "6 - 20 people", "20+ people"],
    answers=["Never", "Sometimes", "About half the time", "Most of the time", "Always"],
    percentage=True,
    stacked=True,
    labelrotation=45,
):

    LIKERT_DATA_IRSEM = get_likert_data(
        survey=IRSEM, questionID=questionID, statements=statements
    )
    LIKERT_DATA_URSSI = get_likert_data(
        survey=URSSI, questionID=questionID, statements=statements
    )

    # create dataframes
    if percentage:
        df1 = pd.DataFrame(
            get_percentages(LIKERT_DATA_IRSEM, answers),
            index=[label for label in statements],
        )
        df2 = pd.DataFrame(
            get_percentages(LIKERT_DATA_URSSI, answers),
            index=[label for label in statements],
        )
    else:
        df1 = pd.DataFrame(
            get_ans_counts(LIKERT_DATA_IRSEM, answers),
            index=[label for label in statements],
        )
        df2 = pd.DataFrame(
            get_ans_counts(LIKERT_DATA_URSSI, answers),
            index=[label for label in statements],
        )

    # plot
    fig, (ax1, ax2) = plt.subplots(1, 2)
    fig.suptitle(title)  # Title

    ax1 = df1.plot.bar(rot=0, ax=ax1, stacked=stacked)
    ax1.set_title(IRSEMsubtitle)
    ax1.set_ylabel("Percentage %") if percentage else ax1.set_ylabel("Frequency")
    ax1.tick_params("x", labelrotation=labelrotation)
    if percentage:
        ax1.set_yticks(np.arange(0, 100.1, 5), minor=True)
    ax1.get_legend().remove()

    ax2 = df2.plot.bar(rot=0, ax=ax2, stacked=stacked)
    ax2.set_title(URSSIsubtitle)
    ax2.tick_params("x", labelrotation=labelrotation)
    if percentage:
        ax2.set_yticks(np.arange(0, 100.1, 5), minor=True)

    # edit parameters
    plt.legend(bbox_to_anchor=(1.02, 1))
    plt.gcf().set_size_inches(12, 6)
    plt.show()
