# text function: print a set of questions (aka a Likert Matrix)
def print_question_set(question="", statements=[], survey=0, percentages=True):
    div = "___________________"
    for i, statement in enumerate(statements):
        print(statement + ":\n")
        print_question(
            question + "_" + str(i + 1), survey=survey, percentages=percentages
        )
        if i < len(statements) - 1:
            print("\n", div * 3, "\n")
