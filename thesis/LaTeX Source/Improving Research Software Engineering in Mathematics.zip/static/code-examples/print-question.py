# text function: print the answer counts, percentage, and totals for a given question
def print_question(questionID="Q0.1", survey=0, percentages=True, totals=True):
    if survey == 0 or survey == 1:
        questions = IRSEM[questionID][2:]
        if percentages:
            df = pd.concat(
                [
                    questions.value_counts(),
                    questions.value_counts(normalize=True).round(2),
                ],
                axis=1,
                keys=["IRSEM survey: counts", "percentages"],
            )
        else:
            df = pd.concat(
                [questions.value_counts()], axis=1, keys=["IRSEM survey: counts"]
            )

        if totals:
            df.loc["TOTAL:"] = df.sum(numeric_only=True, axis=0)

        print(df)

    if survey == 0:
        print("\n - - - - -\n")

    if survey == 0 or survey == 2:
        questions = URSSI[questionID][2:]
        if percentages:
            df = pd.concat(
                [
                    questions.value_counts(),
                    questions.value_counts(normalize=True).round(2),
                ],
                axis=1,
                keys=["URSSI survey: counts", "percentages"],
            )
        else:
            df = pd.concat(
                [questions.value_counts()], axis=1, keys=["URSSI survey: counts"]
            )

        if totals:
            df.loc["TOTAL:"] = df.sum(numeric_only=True, axis=0)

        print(df)
